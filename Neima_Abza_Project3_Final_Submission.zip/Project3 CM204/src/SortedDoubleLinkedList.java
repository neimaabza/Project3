
/**
 * @author Neima Abza
 */
import java.util.Comparator;
import java.util.ListIterator;

public class SortedDoubleLinkedList <T> extends BasicDoubleLinkedList<T> {
	
	protected Comparator<T> comparator;
	/**
	 * Creates an empty list that is associated with the specified comparator.
	 * @param comp comparator to compare data elements.
	 */
	public SortedDoubleLinkedList(Comparator<T> comp) {
		head = null;
		tail = null;
		size = 0;
		comparator = comp;
	}
	/**
	 * Inserts the specified element at the correct position in the sorted list 
	 * it will insert the same element several times.
	 * @param data the data to be added to the list
	 * @return a reference to the current object.
	 */
	public SortedDoubleLinkedList<T> add(T data){
		
		Node newNode = new Node(data);
		
		if(data == null) {
			return this;
		}
		
		if(head == null) {
			head = tail = new Node(data);
		}
		else {
			if(comparator.compare(data, head.data) <= 0) {
				newNode.next = head;
				head = newNode;
			}
			else if(comparator.compare(data, tail.data) >= 0) {
				tail.next = newNode;
				tail = newNode;
			}
			else {
				Node next = head.next;
				Node prev = head;
				
				while(comparator.compare(data, next.data) > 0) {
					prev = next;
					next = next.next;
				}
				prev.next =newNode;
				newNode.next = next;
			}
		}
		size++;
		return this;
	
	}
	/**
	 * this operation is invalid for a sorted list.
	 */
	@Override
	public BasicDoubleLinkedList<T> addToEnd(T data) throws UnsupportedOperationException {
		
		throw new UnsupportedOperationException("Invalid operation for sorted list");
		
	}
	/**
	 * this operation is invalid for a sorted list.
	 */
	@Override
	public BasicDoubleLinkedList<T> addToFront(T data)throws UnsupportedOperationException {
		
		throw new UnsupportedOperationException();
	}
		
	

	@Override
	public ListIterator<T> iterator() {
		return new DoubleLinkedListIterator();
		
		
	}

	@Override
	public BasicDoubleLinkedList<T> remove(T targetData, Comparator<T> comparator) {
		
		return super.remove(targetData, comparator);
	}
}