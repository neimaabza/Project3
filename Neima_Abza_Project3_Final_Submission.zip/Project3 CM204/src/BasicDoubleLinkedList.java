/**
 * @author Neima Abza
 */




import java.util.ArrayList;
import java.util.Comparator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class BasicDoubleLinkedList<T> implements Iterable<T>{
	
	protected Node head;
	protected Node tail;
	protected int size;
	

	public BasicDoubleLinkedList() {
		head = null;
		tail = null;
		size = 0;
		
	}

	public int getSize() {
		return size;
	}
	

	public BasicDoubleLinkedList<T> addToEnd(T data){
				
		if(head == null) {
			head = new Node(data);
			tail = head;
		}
		else {
			Node newe = new Node (data);
			newe.prev = tail;
			tail.next = newe;
			tail = newe;
		}
		size++;
		return this;
	}
	

	public BasicDoubleLinkedList<T> addToFront(T data){
		
		if(head == null) {
			head = new Node(data);
			tail = head;
		}
		else {
			Node newe = new Node(data);
			head.prev = newe;
			newe.next =head;
			head = newe;
		}
		size++;
		return this;
	}

	public T getFirst() {
		return head.data;
	}

	public T getLast() {
		return tail.data;
	}

	public BasicDoubleLinkedList<T> remove(T targetData,
            Comparator<T> comparator){
		
		Node currentNode = head;
		Node prevNode = null;
		
		while(currentNode != null) {
			if(comparator.compare(currentNode.data, targetData) == 0) {
				
				if(currentNode == head) {
					head = head.next;
					currentNode = head;
				}
				else if(currentNode == tail) {
					currentNode = null;
					tail = prevNode;
					prevNode.next = null;
				}
				else {
					prevNode.next =currentNode.next;
					currentNode = currentNode.next;
				}
				size--;
			}
			else {
				prevNode = currentNode;
				currentNode = currentNode.next;
			}
		}
		return this;
	}
					

	public T retrieveFirstElement(){
		if (size == 0) {
			throw new NoSuchElementException();
		}
		Node tmp = head;
		head = head.next;
		head.prev = null;
		size--;
		return tmp.data;
	}
	

	public T retrieveLastElement() {
		if(getSize() == 0) {
			return null;
		}
		else {
		
		Node currentNode = head;
		Node prevNode = null;
		
		while(currentNode != null) {
			if(currentNode.equals(tail)) {
				tail = prevNode;
				break;
			}
			
			prevNode = currentNode;
			currentNode = currentNode.next;
		}
		
		
		size--;
		
		return currentNode.data;
		}
		
	}

	public ArrayList<T> toArrayList(){
		ArrayList<T> result = new ArrayList<T>();
		ListIterator<T> listIterator = new DoubleLinkedListIterator();
		
		while( listIterator.hasNext()) {
			result.add( listIterator.next());
			
		}
		
		return result;
	}
	


class Node {
		protected T data;
		protected Node next;
		protected Node prev;
		

		public Node(T dataNode) {
			this.data = dataNode;
			this.next = null;
			this.prev = null;
		}		
}



class DoubleLinkedListIterator implements ListIterator<T> {
	
	private Node currentNode;
	private Node lastNode;

	public DoubleLinkedListIterator() {
		currentNode = head;
		lastNode = null;
	}
	

	public T next() {
		
		T result;
		if(currentNode != null) {
			result = currentNode.data;
			lastNode = currentNode;
			currentNode = currentNode.next;
			if(currentNode != null) {
				currentNode.prev = lastNode; 
			}
			
			return result;
		}
		else 
			throw new NoSuchElementException();
	}

	public boolean hasNext() {
		
		return currentNode != null;
	}
	

	public T previous() {
		
		T result;
		
		if(lastNode != null) {
			currentNode = lastNode;
			lastNode = currentNode.prev;
			result =currentNode.data;
			return result;
		}
		else 
			throw new NoSuchElementException();
		
	}

	public boolean hasPrevious() {
		
		if(lastNode == null)
			return false;
		else
			return true;
	}

	public void add(T d) {
		throw new UnsupportedOperationException();	
	}
	
	public int nextIndex() {
		
		throw new UnsupportedOperationException();
	}

	public int previousIndex() {
		
		throw new UnsupportedOperationException();
	}

	public void remove() {
		
		throw new UnsupportedOperationException();
		
	}
	public void set(T data) {
		
		throw new UnsupportedOperationException();	
	}
	
}
	
	public boolean hasPrevious() throws UnsupportedOperationException {
		
		throw new UnsupportedOperationException();
	}
	
	public T next() throws UnsupportedOperationException {
		
		throw new UnsupportedOperationException();
	}

	public int nextIndex() throws UnsupportedOperationException {
	
		throw new UnsupportedOperationException();
	}
	public T previous() throws UnsupportedOperationException {
	
		throw new UnsupportedOperationException();
	}
	
	public int previousIndex()throws UnsupportedOperationException {
		
		throw new UnsupportedOperationException();
	}
	
	public void remove() throws UnsupportedOperationException {
		
		throw new UnsupportedOperationException();
	
	}
	
	public void set(T arg0) throws UnsupportedOperationException {
	
		throw new UnsupportedOperationException();
	}
	
	public ListIterator<T> iterator() {
	
		return new DoubleLinkedListIterator();
	}

}
	
	


