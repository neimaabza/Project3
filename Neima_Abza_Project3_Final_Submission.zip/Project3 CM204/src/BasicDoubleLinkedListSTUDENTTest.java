/**
 * @author Neima Abza
 * 
 */
//package _solution;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class BasicDoubleLinkedListSTUDENTTest {
	BasicDoubleLinkedList<String> linkedString;
	BasicDoubleLinkedList<Double> linkedDouble;
	BasicDoubleLinkedList<Car> linkedCar;
	StringComparator comparator;
	DoubleComparator comparatorD;
	CarComparator comparatorCar;
	
	public Car s=new Car("Ford", "Escape", 2005);
	public Car t=new Car("Jeep", "wrangler", 2005);
	public Car u=new Car("Honda", "Accord", 2005);
	public Car v=new Car("Subaru", "Legacy", 2005);
	public Car w=new Car("Chevrolet", "Malibu", 2005);
	public Car x=new Car("Toyota", "Camry", 2005);

	public ArrayList<Car> fill = new ArrayList<Car>();
	

	@Before
	public void setUp() throws Exception {
		linkedString = new BasicDoubleLinkedList<String>();
		linkedString.addToEnd("Ethiopia");
		linkedString.addToEnd("USA");
		comparator = new StringComparator();
		
		linkedDouble = new BasicDoubleLinkedList<Double>();
		linkedDouble.addToEnd(15.0);
		linkedDouble.addToEnd(100.0);
		comparatorD = new DoubleComparator();
		
		linkedCar= new BasicDoubleLinkedList<Car>();
		linkedCar.addToEnd(t);
		linkedCar.addToEnd(u);
		comparatorCar = new CarComparator();
	}

	@After
	public void tearDown() throws Exception {
		linkedString = null;
		linkedDouble = null;
		linkedCar = null;
		comparatorD = null;
		comparator = null;
	}

	@Test
	public void testGetSize() {
		assertEquals(2,linkedString.getSize());
		assertEquals(2,linkedDouble.getSize());
		assertEquals(2,linkedCar.getSize());
	}
	
	@Test
	public void testAddToEnd() {
		assertEquals("USA", linkedString.getLast());
		linkedString.addToEnd("End");
		assertEquals("End", linkedString.getLast());
		
		assertEquals(u,linkedCar.getLast());
		linkedCar.addToEnd(v);
		assertEquals(v,linkedCar.getLast());
	}
	
	@Test
	public void testAddToFront() {
		assertEquals("Ethiopia", linkedString.getFirst());
		linkedString.addToFront("Begin");
		assertEquals("Begin", linkedString.getFirst());
		
		assertEquals(t,linkedCar.getFirst());
		linkedCar.addToFront(s);
		assertEquals(s,linkedCar.getFirst());
	}
	
	@Test
	public void testGetFirst() {
		assertEquals("Ethiopia", linkedString.getFirst());
		linkedString.addToFront("New");
		assertEquals("New", linkedString.getFirst());
		
		assertEquals(t,linkedCar.getFirst());
		linkedCar.addToFront(s);
		assertEquals(s,linkedCar.getFirst());
	}

	@Test
	public void testGetLast() {
		assertEquals("USA", linkedString.getLast());
		linkedString.addToEnd("New");
		assertEquals("New", linkedString.getLast());
		
		assertEquals(u,linkedCar.getLast());
		linkedCar.addToEnd(v);
		assertEquals(v,linkedCar.getLast());
	}
	
	@Test
	public void testToArrayList()
	{
		ArrayList<Car> list;
		linkedCar.addToFront(s);
		linkedCar.addToEnd(v);
		list = linkedCar.toArrayList();
		assertEquals(s,list.get(0));
		assertEquals(t,list.get(1));
		assertEquals(u,list.get(2));
		assertEquals(v,list.get(3));
	}
	
	@Test
	public void testIteratorSuccessfulNext() {
		linkedString.addToFront("Begin");
		linkedString.addToEnd("End");
		ListIterator<String> iterator = linkedString.iterator();
		assertEquals(true, iterator.hasNext());
		assertEquals("Begin", iterator.next());
		assertEquals("Ethiopia", iterator.next());
		assertEquals("USA", iterator.next());
		assertEquals(true, iterator.hasNext());
		assertEquals("End", iterator.next());
		
		linkedCar.addToFront(s);
		linkedCar.addToEnd(v);
		ListIterator<Car> iteratorCar = linkedCar.iterator();
		assertEquals(true, iteratorCar.hasNext());
		assertEquals(s, iteratorCar.next());
		assertEquals(t, iteratorCar.next());
		assertEquals(u, iteratorCar.next());
		assertEquals(true, iteratorCar.hasNext());
		assertEquals(v, iteratorCar.next());
	}
	
	@Test
	public void testIteratorSuccessfulPrevious() {
		linkedCar.addToFront(s);
		linkedCar.addToEnd(v);
		ListIterator<Car> iteratorCar = linkedCar.iterator();
		assertEquals(true, iteratorCar.hasNext());
		assertEquals(s, iteratorCar.next());
		assertEquals(t, iteratorCar.next());
		assertEquals(u, iteratorCar.next());
		assertEquals(v, iteratorCar.next());
		assertEquals(true, iteratorCar.hasPrevious());
		assertEquals(v, iteratorCar.previous());
		assertEquals(u, iteratorCar.previous());
		assertEquals(t, iteratorCar.previous());
		assertEquals(s, iteratorCar.previous());
	}
	
	@Test
	public void testIteratorNoSuchElementExceptionNext() {
		linkedCar.addToFront(s);
		linkedCar.addToEnd(v);
		ListIterator<Car> iteratorCar = linkedCar.iterator();		
		assertEquals(true, iteratorCar.hasNext());
		assertEquals(s, iteratorCar.next());
		assertEquals(t, iteratorCar.next());
		assertEquals(u, iteratorCar.next());
		assertEquals(true, iteratorCar.hasNext());
		assertEquals(v, iteratorCar.next());
		
		try{
			//no more elements in list
			iteratorCar.next();
			assertTrue("Did not throw a NoSuchElementException",false);
		}
		catch (NoSuchElementException e)
		{
			assertTrue("Successfully threw a NoSuchElementException",true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the NoSuchElementException", false);
		}
		
	}
	
	@Test
	public void testIteratorNoSuchElementExceptionPrevious() {
		linkedCar.addToFront(s);
		linkedCar.addToEnd(v);
		ListIterator<Car> iteratorCar = linkedCar.iterator();		
		assertEquals(true, iteratorCar.hasNext());
		assertEquals(s, iteratorCar.next());
		assertEquals(t, iteratorCar.next());
		assertEquals(u, iteratorCar.next());
		assertEquals(v, iteratorCar.next());
		assertEquals(true, iteratorCar.hasPrevious());
		assertEquals(v, iteratorCar.previous());
		assertEquals(u, iteratorCar.previous());
		assertEquals(t, iteratorCar.previous());
		assertEquals(s, iteratorCar.previous());
		
		try{
			//no more elements in list
			iteratorCar.previous();
			assertTrue("Did not throw a NoSuchElementException",false);
		}
		catch (NoSuchElementException e)
		{
			assertTrue("Successfully threw a NoSuchElementException",true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the NoSuchElementException", false);
		}
		
	}
	
	@Test
	public void testIteratorUnsupportedOperationException() {
		linkedCar.addToFront(s);
		linkedCar.addToEnd(v);
		ListIterator<Car> iteratorCar = linkedCar.iterator();		
		assertEquals(true, iteratorCar.hasNext());
		assertEquals(s, iteratorCar.next());
		assertEquals(t, iteratorCar.next());
		assertEquals(u, iteratorCar.next());
		assertEquals(true, iteratorCar.hasNext());
		assertEquals(v, iteratorCar.next());
		
		try{
			//remove is not supported for the iterator
			iteratorCar.remove();
			assertTrue("Did not throw a UnsupportedOperationException",false);
		}
		catch (UnsupportedOperationException e)
		{
			assertTrue("Successfully threw a UnsupportedOperationException",true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the UnsupportedOperationException", false);
		}
		
	}
	
	@Test
	public void testRemove() {
		// remove the first
		assertEquals(t, linkedCar.getFirst());
		assertEquals(u, linkedCar.getLast());
		linkedCar.addToFront(s);
		assertEquals(s, linkedCar.getFirst());
		linkedCar.remove(s, comparatorCar);
		assertEquals(t, linkedCar.getFirst());
		//remove from the end of the list
		linkedCar.addToEnd(v);
		assertEquals(v, linkedCar.getLast());
		linkedCar.remove(v, comparatorCar);
		assertEquals(u, linkedCar.getLast());
		//remove from middle of list
		linkedCar.addToFront(s);
		assertEquals(s, linkedCar.getFirst());
		assertEquals(u, linkedCar.getLast());
		linkedCar.remove(t, comparatorCar);
		assertEquals(s, linkedCar.getFirst());
		assertEquals(u, linkedCar.getLast());
		
	}

	@Test
	public void testRetrieveFirstElement() {
		assertEquals(t, linkedCar.getFirst());
		linkedCar.addToFront(s);
		assertEquals(s, linkedCar.getFirst());
		assertEquals(s, linkedCar.retrieveFirstElement());
		assertEquals(t,linkedCar.getFirst());
		assertEquals(t, linkedCar.retrieveFirstElement());
		assertEquals(u,linkedCar.getFirst());
		
		assertEquals("Ethiopia", linkedString.getFirst());
		linkedString.addToFront("New");
		assertEquals("New", linkedString.getFirst());
		assertEquals("New", linkedString.retrieveFirstElement());
		assertEquals("Ethiopia",linkedString.getFirst());
		assertEquals("Ethiopia", linkedString.retrieveFirstElement());
		assertEquals("USA",linkedString.getFirst());
		
	}

	@Test
	public void testRetrieveLastElement() {
		assertEquals(u, linkedCar.getLast());
		linkedCar.addToEnd(v);
		assertEquals(v, linkedCar.getLast());
		assertEquals(v, linkedCar.retrieveLastElement());
		assertEquals(u,linkedCar.getLast());
		
		assertEquals("USA", linkedString.getLast());
		linkedString.addToEnd("New");
		assertEquals("New", linkedString.getLast());
		assertEquals("New", linkedString.retrieveLastElement());
		assertEquals("USA",linkedString.getLast());
	}

	private class StringComparator implements Comparator<String>
	{

		@Override
		public int compare(String arg0, String arg1) {
			// TODO Auto-generated method stub
			return arg0.compareTo(arg1);
		}
		
	}
	
	private class DoubleComparator implements Comparator<Double>
	{

		@Override
		public int compare(Double arg0, Double arg1) {
			// TODO Auto-generated method stub
			return arg0.compareTo(arg1);
		}
		
	}
	
	private class CarComparator implements Comparator<Car>
	{

		@Override
		public int compare(Car arg0, Car arg1) {
			// Just put cars in alphabetic order by make
			return arg0.toString().compareTo(arg1.toString());
		}
		
	}
	
	private class Car{
		String make;
		String model;
		int year;
		
		public Car(String make, String model, int year){
			this.make = make;
			this.model = model;
			this.year = year;
		}
		
		public String getMake(){
			return make;
		}
		public String getModel(){
			return model;
		}
		public int getYear(){
			return year;
		}
		
		public String toString() {
			return (getMake()+" "+getModel()+" "+getYear());
		}
	}
}